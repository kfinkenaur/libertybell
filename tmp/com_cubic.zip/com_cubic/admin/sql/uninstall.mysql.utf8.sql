DROP TABLE IF EXISTS `#__cubic_cubes`;
DROP TABLE IF EXISTS `#__cubic_categories`;
DROP TABLE IF EXISTS `#__cubic_items`;
DROP TABLE IF EXISTS `#__cubic_inventories`;
DROP TABLE IF EXISTS `#__cubic_savedorders`;