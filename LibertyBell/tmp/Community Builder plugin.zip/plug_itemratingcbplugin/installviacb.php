<?php
/**
 * @copyright	Copyright (C) 2009-2015 ACYBA SARL - All rights reserved..
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');
echo 'You MUST install Itemrating via the Community Builder\'s plugin management page, this plugin is NOT made to be installed via the Joomla installer...';
exit;